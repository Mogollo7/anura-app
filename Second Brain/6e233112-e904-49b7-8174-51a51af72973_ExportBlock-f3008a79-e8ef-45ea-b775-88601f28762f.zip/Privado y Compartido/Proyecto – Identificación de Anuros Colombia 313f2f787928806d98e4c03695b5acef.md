# Proyecto – Identificación de Anuros Colombia

[Introducción y Justificación](Proyecto%20%E2%80%93%20Identificaci%C3%B3n%20de%20Anuros%20Colombia/Introducci%C3%B3n%20y%20Justificaci%C3%B3n%20b8c9c9dffed747bfa87c187a1e2bab82.md)

[Objetivos y Alcance](Proyecto%20%E2%80%93%20Identificaci%C3%B3n%20de%20Anuros%20Colombia/Objetivos%20y%20Alcance%2026874fffb0664cf78bee83a86bf17fb5.md)

[Referente Teorico](Proyecto%20%E2%80%93%20Identificaci%C3%B3n%20de%20Anuros%20Colombia/Referente%20Teorico%204721c23f1a4744b6b0412ee88f872e67.md)

[Metodología](Proyecto%20%E2%80%93%20Identificaci%C3%B3n%20de%20Anuros%20Colombia/Metodolog%C3%ADa%208d9a3b5dedff40e1ace2edf7c7889c9b.md)

[Evaluación y Métricas](Proyecto%20%E2%80%93%20Identificaci%C3%B3n%20de%20Anuros%20Colombia/Evaluaci%C3%B3n%20y%20M%C3%A9tricas%2073130dcabfda4e31ae88705d1ec9740b.md)

[Consideraciones Ecológicas](Proyecto%20%E2%80%93%20Identificaci%C3%B3n%20de%20Anuros%20Colombia/Consideraciones%20Ecol%C3%B3gicas%20f8b15b74ccd0485a85b09cd027ca4ede.md)

[Riesgos](Proyecto%20%E2%80%93%20Identificaci%C3%B3n%20de%20Anuros%20Colombia/Riesgos%203036ffdc2edd4d2baabff657e6935fde.md)

[Cronograma](Proyecto%20%E2%80%93%20Identificaci%C3%B3n%20de%20Anuros%20Colombia/Cronograma%20a3e6b46db19743f8be180c834fc55aad.md)

[Experimentos y Resultados](Proyecto%20%E2%80%93%20Identificaci%C3%B3n%20de%20Anuros%20Colombia/Experimentos%20y%20Resultados%207172e481cf6346e7a50fce559760a2b0.md)

[Desarrollo Técnico](Proyecto%20%E2%80%93%20Identificaci%C3%B3n%20de%20Anuros%20Colombia/Desarrollo%20T%C3%A9cnico%204a3c0469c5304d5081483d597077ee70.md)

[Bibliografía](Proyecto%20%E2%80%93%20Identificaci%C3%B3n%20de%20Anuros%20Colombia/Bibliograf%C3%ADa%203c4f2f7879288098b335f4eb44c01826.md)