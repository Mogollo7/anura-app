# Riesgos

## Riesgos del proyecto

- **Riesgos técnicos:**
- **Riesgos de datos:**
- **Riesgos operativos/legales:**
- **Mitigaciones:**