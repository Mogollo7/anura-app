# Consideraciones Ecológicas

## Consideraciones ecológicas y éticas

### Buenas prácticas en campo

- **Manejo y reubicación responsable:**
- **Minimización de impacto:**
- **Bioseguridad:**

### Indicadores de impacto ambiental

- **Número de registros útiles generados:**
- **Tiempo reducido en identificación manual:**
- **Apoyo a procesos de reubicación:**
- **Uso en monitoreo y conservación:**