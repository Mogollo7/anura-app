# 📂 Evaluación en campo real

## Evaluación en campo real

- **Diseño del piloto:** (lugares, duración, número de usuarios)
- **Criterios de éxito:**
- **Registro de errores y casos difíciles:**
- **Métricas en campo:** (tiempo de respuesta, tasa de acierto, tasa de rechazo, etc.)

### Instrumentación

- **Qué se registra en la app:**
- **Consentimiento y privacidad:**
- **Manejo de casos “desconocidos”:**