# 📂 Métricas offline (Top-1, F1, etc.)

## Métricas offline (pruebas controladas)

- **Top-1 Accuracy:**
- **Top-3 Accuracy:**
- **Recall:**
- **F1-score:**

### Configuración de evaluación

- **Conjunto de test:**
- **Balance de clases:**
- **Métrica principal:**
- **Métricas secundarias:**

### Registro de resultados

- **Fecha:**
- **Versión del modelo:**
- **Versión del dataset:**
- **Notas:**