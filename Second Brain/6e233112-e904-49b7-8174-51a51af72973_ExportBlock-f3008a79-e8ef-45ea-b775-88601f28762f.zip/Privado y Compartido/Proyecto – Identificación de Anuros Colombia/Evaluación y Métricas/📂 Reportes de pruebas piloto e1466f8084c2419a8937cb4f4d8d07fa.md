# 📂 Reportes de pruebas piloto

## Reportes de pruebas piloto

### Reporte (plantilla)

- **Fecha:**
- **Lugar:**
- **Participantes:**
- **Versión app:**
- **Versión modelo:**
- **Resumen de hallazgos:**
- **Problemas detectados:**
- **Acciones siguientes:**