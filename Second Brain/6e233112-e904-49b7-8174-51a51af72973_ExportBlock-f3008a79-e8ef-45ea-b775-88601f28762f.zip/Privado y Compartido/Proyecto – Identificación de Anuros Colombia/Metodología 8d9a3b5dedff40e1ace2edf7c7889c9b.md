# Metodología

## Metodología

[Estrategia de construcción de dataset](Metodolog%C3%ADa/Estrategia%20de%20construcci%C3%B3n%20de%20dataset%20f862818e339b4787b5e841a43512dc03.md)

[📂 Arquitectura multimodal](Metodolog%C3%ADa/%F0%9F%93%82%20Arquitectura%20multimodal%20c4a3cd958dee4020aafe58fd93ffe28b.md)

[📂 Pipeline del sistema](Metodolog%C3%ADa/%F0%9F%93%82%20Pipeline%20del%20sistema%20a06da528d8454f799b1da6592b235c4a.md)

[📂 Infraestructura](Metodolog%C3%ADa/%F0%9F%93%82%20Infraestructura%208a785f78fc5b453281aa7561bc7b3d87.md)

[📂 Open-set recognition](Metodolog%C3%ADa/%F0%9F%93%82%20Open-set%20recognition%2020dd7536038345b0b2b16659ad189fca.md)

[📂 Escalabilidad](Metodolog%C3%ADa/%F0%9F%93%82%20Escalabilidad%203396d80db50249fbbcfb0b3f7a6eec0c.md)