# 📂 Arquitectura multimodal

## Arquitectura multimodal

### Rama visual

- **Entrada:** (tamaño, normalización)
- **Backbone:** (EfficientNet-
- **Salida/embedding:** (dimensión)
- **Pérdida:** (Triplet loss / etc.)

### Rama de audio

- **Entrada:** (espectrograma, mel, ventana)
- **Backbone:**
- **Salida/embedding:**

### Rama de metadatos

- **Campos usados:** (ubicación, fecha, altitud, hábitat, etc.)
- **Codificación:** (one-hot, embeddings, normalización)
- **Modelo:** (MLP / etc.)

### Fusión

- **Tipo de fusión:** (concatenación, atención, late fusion)
- **Bloques posteriores:**
- **Criterio de decisión:**