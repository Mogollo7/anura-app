# 📂 Pipeline del sistema

## Pipeline del sistema

### Flujo extremo a extremo

- **Entrada (app):**
- **Preprocesamiento:**
- **Inferencia:**
- **Búsqueda en base vectorial:**
- **Salida (predicción + explicación):**