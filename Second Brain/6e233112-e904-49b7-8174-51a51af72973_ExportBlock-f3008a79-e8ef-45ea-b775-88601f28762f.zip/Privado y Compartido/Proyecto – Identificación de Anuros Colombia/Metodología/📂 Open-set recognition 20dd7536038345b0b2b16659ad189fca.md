# 📂 Open-set recognition

## Open-set recognition

- **Definición de “desconocido”:**
- **Estrategia:** (umbral, distancia en embedding, clasificador de rechazo)
- **Protocolo de evaluación:**