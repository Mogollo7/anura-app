# 📂 Escalabilidad

## Escalabilidad

- **Agregar nuevas especies:** (proceso)
- **Actualizaciones del modelo:** (frecuencia, versionado)
- **Crecimiento del índice vectorial:** (estrategia)