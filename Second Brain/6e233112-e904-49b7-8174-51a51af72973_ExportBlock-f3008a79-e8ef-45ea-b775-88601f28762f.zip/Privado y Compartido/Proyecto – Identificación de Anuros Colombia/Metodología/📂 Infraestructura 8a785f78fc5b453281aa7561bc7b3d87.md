# 📂 Infraestructura

## Infraestructura

- **Modelo en servidor:** (sí/no, por qué)
- **Latencia objetivo:**
- **Costo objetivo:**
- **Monitoreo:** (drift, calidad, errores)