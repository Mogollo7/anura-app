# Evaluación y Métricas

## Evaluación y métricas

[📂 Métricas offline (Top-1, F1, etc.)](Evaluaci%C3%B3n%20y%20M%C3%A9tricas/%F0%9F%93%82%20M%C3%A9tricas%20offline%20(Top-1,%20F1,%20etc%20)%206741fc866c0242978fc257a7634e9590.md)

[📂 Evaluación en campo real](Evaluaci%C3%B3n%20y%20M%C3%A9tricas/%F0%9F%93%82%20Evaluaci%C3%B3n%20en%20campo%20real%207f599fdd72eb4cbb85bf285578aa6a40.md)

[📂 Matrices de confusión](Evaluaci%C3%B3n%20y%20M%C3%A9tricas/%F0%9F%93%82%20Matrices%20de%20confusi%C3%B3n%20391041e0249c414e93212698863e1760.md)

[📂 Reportes de pruebas piloto](Evaluaci%C3%B3n%20y%20M%C3%A9tricas/%F0%9F%93%82%20Reportes%20de%20pruebas%20piloto%20e1466f8084c2419a8937cb4f4d8d07fa.md)